const express = require("express");

const router = express.Router();

const upload = require("../middleware/upload");

const {
    uploadFile,
    getFiles
} = require("../controllers/fileController");


// Upload single file
router.post(
    "/upload",
    upload.single("file"),
    uploadFile
);


// Get all files
router.get(
    "/",
    getFiles
);


module.exports = router;