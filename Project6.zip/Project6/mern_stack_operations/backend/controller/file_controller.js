const File = require("../models/File");
// Upload single file
const uploadFile = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                message: "Please select a file"
            });
        }

        const file = await File.create({
            originalName: req.file.originalname,
            fileName: req.file.filename,
            mimeType: req.file.mimetype,
            size: req.file.size,
            path: req.file.path,
            folder: req.body.folder || "General"
        });

        res.status(201).json({
            message: "File uploaded successfully",
            file: file
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            message: "File upload failed",
            error: error.message
        });
    }
};


// Get all files
const getFiles = async (req, res) => {
    try {
        const files = await File.find()
            .sort({ createdAt: -1 });

        res.status(200).json(files);

    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch files",
            error: error.message
        });
    }
};


module.exports = {
    uploadFile,
    getFiles
};